# REST API reference

Base URL: `http://localhost:8000/api`. All bodies are JSON. Errors look like `{"error": "message"}`.
Authenticated routes need `Authorization: Bearer <token>`. Device ingestion can use `X-API-Key: <DEVICE_API_KEY>`.

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/health` | none | Liveness check |
| GET | `/ports` | none | List ports with UN/LOCODE and coordinates |
| POST | `/auth/register` | none | Create a customer account (`name`, `email`, `password` ≥ 8 chars) |
| POST | `/auth/login` | none | Returns `token` and `user` |
| GET | `/auth/me` | user | Current user |
| GET | `/track/{container_no or reference}` | none | Public tracking: status, route, progress, ETA, alerts, event history |
| GET | `/shipments?status=IN_TRANSIT` | user | Shipments (customers see only their own) |
| GET | `/shipments/{reference}` | user | Full tracking document for one shipment |
| POST | `/shipments` | admin | Create a shipment (`container_no`, `origin`, `destination`, optional `customer_email`, `vessel`, `voyage`, `etd`, `eta`) |
| GET | `/containers` | user | List containers |
| POST | `/containers` | admin | Register a container (ISO 6346 validated) |
| POST | `/events` | admin or device key | Add a position, temperature or status event |
| GET | `/alerts` | user | Open alerts (DELAY, TEMPERATURE, STALE) |
| GET | `/stats` | user | Dashboard counters |

## Event body
```json
{
  "container_no": "BXTU7781205",
  "status": "IN_TRANSIT",
  "lat": 34.1,
  "lon": -150.2,
  "temperature": 4.5,
  "location_name": "North Pacific",
  "note": "Routine position report",
  "occurred_at": "2026-10-01T08:30:00Z"
}
```
`status` is optional (position-only updates leave the shipment status unchanged). Valid statuses:
`BOOKED, GATED_IN, LOADED, IN_TRANSIT, TRANSSHIPMENT, ARRIVED, DISCHARGED, DELIVERED`.

## curl examples
```bash
# Public tracking
curl http://localhost:8000/api/track/BXTU2045182

# Sign in as admin
TOKEN=$(curl -s -X POST http://localhost:8000/api/auth/login -H 'Content-Type: application/json' \
  -d '{"email":"admin@boxtrace.test","password":"admin12345"}' | python3 -c 'import sys,json;print(json.load(sys.stdin)["token"])')

# Register a container and create a shipment
curl -X POST http://localhost:8000/api/containers -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"container_no":"CSQU3054383","size_type":"40HC"}'
curl -X POST http://localhost:8000/api/shipments -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"container_no":"CSQU3054383","origin":"INNSA","destination":"NLRTM","customer_email":"customer@boxtrace.test"}'

# Device posts a position
curl -X POST http://localhost:8000/api/events -H 'X-API-Key: dev-device-key' -H 'Content-Type: application/json' \
  -d '{"container_no":"CSQU3054383","status":"IN_TRANSIT","lat":15.0,"lon":65.0}'
```
