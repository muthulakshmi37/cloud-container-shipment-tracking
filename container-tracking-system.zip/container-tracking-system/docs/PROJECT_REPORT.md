# Cloud-Based Container Shipment Tracking System – Project Report

## 1. Abstract
Global container shipping moves most of the world's traded goods, yet customers often lack timely, trustworthy
information on where a container is and when it will arrive. This project builds BoxTrace, a cloud-deployable web
system that ingests position, temperature and status events for shipping containers, presents them on an interactive
map, predicts arrival times, and raises alerts for delays and cargo-condition problems.

## 2. Problem statement
Operators and customers use fragmented tools (emails, spreadsheets, carrier portals) to follow containers. Delays and
temperature excursions on refrigerated cargo are found late, which causes spoilage, demurrage charges and missed
deliveries. A single cloud-hosted service with an open API can give both groups one live view.

## 3. Objectives
1. Register containers with ISO 6346 validation and manage shipments between ports.
2. Receive tracking events from devices or operators through a secured API.
3. Show live status, route progress and event history to customers on a map.
4. Predict arrival time and generate delay, temperature and stale-data alerts automatically.
5. Restrict data by role (customer vs administrator).
6. Package the system in a container image that runs on any cloud.

## 4. Requirements
### Functional
| ID | Requirement |
|---|---|
| F1 | Users can register, sign in and sign out |
| F2 | Administrators can register containers and create shipments |
| F3 | Devices and administrators can submit tracking events |
| F4 | Anyone can look up a container or shipment reference and see its status without signing in |
| F5 | Customers can list only their own shipments; administrators see all |
| F6 | System computes progress, predicted ETA and alerts |
| F7 | Dashboard shows counters, alerts and shipments |
### Non-functional
Security (hashed passwords, signed expiring tokens, key-protected device API), portability (Docker), reliability
(health check, input validation), maintainability (automated tests, documented API), usability (responsive UI).

## 5. System architecture
```
 Devices / AIS / operators --HTTPS--> [ Load balancer ] --> [ Flask API in Docker (Gunicorn) ] --> [ Database ]
 Browser (Leaflet map UI) ---HTTPS--->                        serves static UI + REST /api             (SQLite/EFS or RDS)
```
Layers: presentation (static HTML/CSS/JS), application (Flask blueprint, tracking services), data (SQLite).
Cloud services (AWS example): ECR for images, ECS Fargate for compute, ALB with ACM certificate, EFS or RDS for
data, Secrets Manager for keys, CloudWatch for logs.

## 6. Database design
Entities: **users**, **ports**, **containers**, **shipments**, **events**.
- A user (customer) owns many shipments.
- A container has many shipments over time; only one may be active.
- A shipment links one container, an origin port and a destination port, and has many events.
- An event records status, optional coordinates, optional temperature, timestamp and its source (device, operator, system).

```
users 1---* shipments *---1 containers
                |  *---1 ports (origin)      shipments 1---* events
                |  *---1 ports (destination)
```
The DDL is in `app/schema.sql`.

## 7. Key algorithms
- **ISO 6346 check digit**: each character gets a value (letters skip multiples of 11); values are multiplied by 2^position, summed, taken mod 11, then mod 10.
- **Distance**: haversine formula on a sphere of radius 6371 km.
- **Progress**: 1 − (remaining distance ÷ origin-to-destination distance), capped below 100% until arrival.
- **ETA prediction**: last position time + remaining distance ÷ average speed (24 km/h by default).
- **Alert rules**: delay = predicted − planned ≥ 24 h (critical at 72 h); temperature outside the reefer range; no update for more than 12 h while at sea.

## 7a. Security
Passwords are hashed (Werkzeug); tokens are signed and expire; device ingestion uses a constant-time key check; SQL uses
parameterised queries; the UI escapes all server text before rendering; public tracking returns no customer data.

## 8. Testing
Fifteen automated tests cover ISO 6346 validation, geo maths, authentication, role restrictions, container and shipment
rules, device ingestion validation, alert generation and customer data isolation. Run with
`python -m unittest discover -s tests -t . -v`.

| Test area | Example case | Expected result |
|---|---|---|
| Container validation | Wrong check digit | 400 error |
| Access control | Customer creates container | 403 error |
| Ingestion | No API key | 401 error |
| Ingestion | Latitude 123 | 400 error |
| Alerts | Reefer at 12.5 °C with range 2–8 °C | TEMPERATURE alert |
| Isolation | New customer lists shipments | Empty list |

## 9. Results
The system registers containers, follows shipments end to end, updates the map as events arrive (demonstrated with the
simulator), and surfaces delayed and out-of-range cargo on the dashboard.

## 10. Limitations and future work
Real shipping-lane routing and AIS integration; multi-container bookings and bills of lading; PostgreSQL and horizontal
scaling; push notifications by email/SMS/WebSocket; geofencing and port-congestion data; role for carrier staff; mobile app.

## 11. Conclusion
BoxTrace shows that a small containerised service can give shippers timely visibility, early warning of problems, and an
open API for integration, while remaining simple to deploy on any major cloud.
