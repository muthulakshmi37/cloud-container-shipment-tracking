# Deploying to AWS (ECS Fargate)

Architecture: Route 53 → Application Load Balancer (HTTPS via ACM) → ECS Fargate service (this container)
→ EFS volume for the SQLite file. Secrets come from AWS Secrets Manager; logs go to CloudWatch.

## 1. Build and push the image
```bash
aws ecr create-repository --repository-name boxtrace
aws ecr get-login-password --region <REGION> | docker login --username AWS --password-stdin <ACCOUNT_ID>.dkr.ecr.<REGION>.amazonaws.com
docker build -t boxtrace .
docker tag boxtrace:latest <ACCOUNT_ID>.dkr.ecr.<REGION>.amazonaws.com/boxtrace:latest
docker push <ACCOUNT_ID>.dkr.ecr.<REGION>.amazonaws.com/boxtrace:latest
```

## 2. Create supporting resources
1. Secrets Manager: `boxtrace/secret-key` and `boxtrace/device-key` (long random strings).
2. EFS file system in the same VPC, with mount targets in each private subnet and a security group that allows NFS (2049) from the service.
3. CloudWatch log group `/ecs/boxtrace`.

## 3. Register the task and run the service
Fill the placeholders in `task-definition.json`, then:
```bash
aws ecs create-cluster --cluster-name boxtrace
aws ecs register-task-definition --cli-input-json file://deploy/aws/task-definition.json
aws ecs create-service --cluster boxtrace --service-name boxtrace-web --task-definition boxtrace \
  --desired-count 1 --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[<SUBNET_A>,<SUBNET_B>],securityGroups=[<SG>],assignPublicIp=DISABLED}" \
  --load-balancers "targetGroupArn=<TARGET_GROUP_ARN>,containerName=web,containerPort=8000"
```
Point the target group health check at `/api/health`.

## 4. Create the first admin
Run once with `SEED_DEMO=true` to load demo data, or open an ECS Exec shell and insert your own admin user.
Change the demo passwords immediately, or leave `SEED_DEMO=false` in production.

## Scaling note
SQLite on EFS is fine for one running task (demo, coursework, small fleets). To run several tasks behind the load
balancer, replace `app/db.py` with a PostgreSQL implementation (Amazon RDS) so all tasks share one database.

## Other clouds
The same image runs on Azure Container Apps, Google Cloud Run (add a volume or Cloud SQL), Render, Railway or Heroku
(`Procfile` included).
