#!/usr/bin/env python3
"""IoT / AIS device simulator.

Moves a container along the great-circle route between two ports and posts
position (and reefer temperature) events to the tracking API, the way a
telematics unit would.

Example:
    python scripts/simulator.py --container BXTU9932152 --from KRPUS --to USLGB \
        --api http://localhost:8000 --key dev-device-key --steps 20 --interval 2
"""
import argparse
import json
import math
import random
import sys
import urllib.error
import urllib.request

EARTH_KM = 6371.0088


def haversine_km(a, b):
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dl = math.radians(b[1] - a[1])
    h = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_KM * math.asin(math.sqrt(h))


def interpolate(a, b, f):
    p1, l1, p2, l2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    d = haversine_km(a, b) / EARTH_KM
    if d == 0:
        return a
    x_ = math.sin((1 - f) * d) / math.sin(d)
    y_ = math.sin(f * d) / math.sin(d)
    x = x_ * math.cos(p1) * math.cos(l1) + y_ * math.cos(p2) * math.cos(l2)
    y = x_ * math.cos(p1) * math.sin(l1) + y_ * math.cos(p2) * math.sin(l2)
    z = x_ * math.sin(p1) + y_ * math.sin(p2)
    return math.degrees(math.atan2(z, math.hypot(x, y))), math.degrees(math.atan2(y, x))


def call(method, url, payload=None, headers=None):
    req = urllib.request.Request(url, method=method, headers={"Content-Type": "application/json", **(headers or {})},
                                 data=None if payload is None else json.dumps(payload).encode())
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        sys.exit(f"API error {e.code}: {e.read().decode()}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--container", required=True)
    ap.add_argument("--from", dest="origin", required=True, help="origin UN/LOCODE, e.g. KRPUS")
    ap.add_argument("--to", dest="dest", required=True, help="destination UN/LOCODE, e.g. USLGB")
    ap.add_argument("--api", default="http://localhost:8000")
    ap.add_argument("--key", default="dev-device-key")
    ap.add_argument("--steps", type=int, default=15)
    ap.add_argument("--interval", type=float, default=1.0, help="seconds between real-time posts")
    ap.add_argument("--reefer-temp", type=float, default=None, help="base temperature for reefer containers")
    args = ap.parse_args()

    ports = {p["unlocode"]: p for p in call("GET", f"{args.api}/api/ports")}
    for code in (args.origin, args.dest):
        if code not in ports:
            sys.exit(f"Unknown port {code}. Known: {', '.join(sorted(ports))}")
    a = (ports[args.origin]["lat"], ports[args.origin]["lon"])
    b = (ports[args.dest]["lat"], ports[args.dest]["lon"])
    # Events are stamped by the server with the current time, so the voyage is
    # compressed into the run: one post every --interval seconds.
    headers = {"X-API-Key": args.key}
    import time
    for i in range(args.steps + 1):
        f = i / args.steps
        lat, lon = interpolate(a, b, f)
        body = {
            "container_no": args.container, "lat": round(lat, 4), "lon": round(lon, 4),
            "status": "LOADED" if i == 0 else ("ARRIVED" if i == args.steps else "IN_TRANSIT"),
        }
        if args.reefer_temp is not None:
            body["temperature"] = round(args.reefer_temp + random.uniform(-0.6, 0.6), 1)
        out = call("POST", f"{args.api}/api/events", body, headers)
        print(f"[{i:>3}/{args.steps}] {body['lat']:>8}, {body['lon']:>9}  -> {out['status']} "
              f"{out['progress_percent']}%  alerts={len(out['alerts'])}")
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
