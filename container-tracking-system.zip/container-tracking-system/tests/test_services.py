import unittest

from app.services import haversine_km, interpolate


class GeoTests(unittest.TestCase):
    def test_haversine_known_distance(self):
        # Rotterdam to Hamburg is roughly 400 km in a straight line
        d = haversine_km(51.949, 4.142, 53.5461, 9.9661)
        self.assertAlmostEqual(d, 430, delta=40)

    def test_interpolate_endpoints_and_midpoint(self):
        a, b = (1.2644, 103.82), (51.949, 4.142)
        lat0, lon0 = interpolate(*a, *b, 0)
        lat1, lon1 = interpolate(*a, *b, 1)
        self.assertAlmostEqual(lat0, a[0], places=3)
        self.assertAlmostEqual(lon1, b[1], places=3)
        mid = interpolate(*a, *b, 0.5)
        total = haversine_km(*a, *b)
        self.assertAlmostEqual(haversine_km(*a, *mid), total / 2, delta=5)


if __name__ == "__main__":
    unittest.main()
