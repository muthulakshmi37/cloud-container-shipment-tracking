import os
import tempfile
import unittest
from datetime import timedelta

from app import create_app
from app.services import to_iso, utcnow


class ApiTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.app = create_app({"DATABASE_PATH": self.path, "SEED_DEMO": True, "TESTING": True,
                               "DEVICE_API_KEY": "test-key", "SECRET_KEY": "test-secret"})
        self.c = self.app.test_client()

    def tearDown(self):
        for suffix in ("", "-wal", "-shm"):
            try:
                os.remove(self.path + suffix)
            except FileNotFoundError:
                pass

    def login(self, email, password):
        r = self.c.post("/api/auth/login", json={"email": email, "password": password})
        self.assertEqual(r.status_code, 200, r.get_json())
        return {"Authorization": "Bearer " + r.get_json()["token"]}

    def admin(self):
        return self.login("admin@boxtrace.test", "admin12345")

    # --- auth
    def test_bad_login_rejected(self):
        r = self.c.post("/api/auth/login", json={"email": "admin@boxtrace.test", "password": "wrong-password"})
        self.assertEqual(r.status_code, 401)

    def test_register_and_me(self):
        r = self.c.post("/api/auth/register", json={"name": "Asha", "email": "asha@example.com", "password": "longenough1"})
        self.assertEqual(r.status_code, 201)
        h = {"Authorization": "Bearer " + r.get_json()["token"]}
        self.assertEqual(self.c.get("/api/auth/me", headers=h).get_json()["role"], "customer")
        dup = self.c.post("/api/auth/register", json={"name": "A", "email": "asha@example.com", "password": "longenough1"})
        self.assertEqual(dup.status_code, 409)

    def test_protected_routes_need_token(self):
        self.assertEqual(self.c.get("/api/shipments").status_code, 401)
        self.assertEqual(self.c.get("/api/stats").status_code, 401)

    # --- containers and shipments
    def test_container_validation_and_admin_only(self):
        cust = self.login("customer@boxtrace.test", "customer12345")
        body = {"container_no": "CSQU3054383", "size_type": "40HC"}
        self.assertEqual(self.c.post("/api/containers", json=body, headers=cust).status_code, 403)
        adm = self.admin()
        self.assertEqual(self.c.post("/api/containers", json={**body, "container_no": "CSQU3054384"}, headers=adm).status_code, 400)
        self.assertEqual(self.c.post("/api/containers", json=body, headers=adm).status_code, 201)
        self.assertEqual(self.c.post("/api/containers", json=body, headers=adm).status_code, 409)

    def test_full_shipment_lifecycle(self):
        adm = self.admin()
        self.c.post("/api/containers", json={"container_no": "CSQU3054383", "size_type": "20RF", "temp_min": 2, "temp_max": 8}, headers=adm)
        eta = to_iso(utcnow() + timedelta(days=20))
        r = self.c.post("/api/shipments", headers=adm, json={
            "container_no": "CSQU3054383", "origin": "INNSA", "destination": "NLRTM",
            "customer_email": "customer@boxtrace.test", "vessel": "MV Test", "eta": eta})
        self.assertEqual(r.status_code, 201, r.get_json())
        ref = r.get_json()["reference"]
        # second active shipment for the same box is refused
        dup = self.c.post("/api/shipments", headers=adm, json={"container_no": "CSQU3054383", "origin": "INNSA", "destination": "NLRTM"})
        self.assertEqual(dup.status_code, 409)

        # device posts events
        key = {"X-API-Key": "test-key"}
        e = self.c.post("/api/events", headers=key, json={
            "container_no": "CSQU3054383", "status": "IN_TRANSIT", "lat": 15.0, "lon": 65.0, "temperature": 12.5})
        self.assertEqual(e.status_code, 201, e.get_json())
        self.assertIn("TEMPERATURE", [a["type"] for a in e.get_json()["alerts"]])

        t = self.c.get("/api/track/CSQU3054383").get_json()
        self.assertEqual(t["reference"], ref)
        self.assertEqual(t["status"], "IN_TRANSIT")
        self.assertGreater(t["progress_percent"], 0)
        self.assertNotIn("customer", str(t).lower().replace("customer@", ""))  # no customer data leaks publicly
        self.assertEqual(self.c.get(f"/api/track/{ref}").status_code, 200)

    def test_event_auth_and_validation(self):
        body = {"container_no": "BXTU2045182", "lat": 10, "lon": 20}
        self.assertEqual(self.c.post("/api/events", json=body).status_code, 401)
        self.assertEqual(self.c.post("/api/events", json=body, headers={"X-API-Key": "nope"}).status_code, 401)
        key = {"X-API-Key": "test-key"}
        self.assertEqual(self.c.post("/api/events", json={**body, "lat": 123}, headers=key).status_code, 400)
        self.assertEqual(self.c.post("/api/events", json={**body, "status": "FLYING"}, headers=key).status_code, 400)
        self.assertEqual(self.c.post("/api/events", json={"container_no": "BXTU0000000"}, headers=key).status_code, 404)
        self.assertEqual(self.c.post("/api/events", json=body, headers=key).status_code, 201)

    # --- tracking rules on seeded demo data
    def test_seed_alerts(self):
        adm = self.admin()
        alerts = self.c.get("/api/alerts", headers=adm).get_json()
        kinds = {a["type"] for a in alerts}
        self.assertIn("DELAY", kinds)
        self.assertIn("TEMPERATURE", kinds)
        stats = self.c.get("/api/stats", headers=adm).get_json()
        self.assertEqual(stats["total_shipments"], 6)

    def test_customer_only_sees_own_shipments(self):
        self.c.post("/api/auth/register", json={"name": "Other", "email": "other@example.com", "password": "longenough1"})
        other = self.login("other@example.com", "longenough1")
        self.assertEqual(self.c.get("/api/shipments", headers=other).get_json(), [])
        self.assertEqual(self.c.get("/api/shipments/SHP-2026-100001", headers=other).status_code, 404)
        cust = self.login("customer@boxtrace.test", "customer12345")
        self.assertEqual(len(self.c.get("/api/shipments", headers=cust).get_json()), 6)

    def test_unknown_lookups(self):
        self.assertEqual(self.c.get("/api/track/BXTU0000000").status_code, 404)
        self.assertEqual(self.c.get("/api/nothing").status_code, 404)
        self.assertEqual(self.c.get("/api/health").get_json(), {"status": "ok"})


if __name__ == "__main__":
    unittest.main()
