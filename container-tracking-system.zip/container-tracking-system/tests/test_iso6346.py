import unittest

from app import iso6346


class Iso6346Tests(unittest.TestCase):
    def test_valid_numbers(self):
        for n in ("CSQU3054383", "csqu 305438-3", "BXTU2045182"):
            self.assertTrue(iso6346.is_valid(n), n)

    def test_bad_check_digit(self):
        self.assertFalse(iso6346.is_valid("CSQU3054384"))

    def test_bad_format(self):
        for n in ("", "CSQU305438", "1234567890A", "CSQX3054383"):
            self.assertFalse(iso6346.is_valid(n), n)

    def test_letter_values_skip_multiples_of_eleven(self):
        self.assertEqual(iso6346.LETTER_VALUES["A"], 10)
        self.assertEqual(iso6346.LETTER_VALUES["B"], 12)
        self.assertEqual(iso6346.LETTER_VALUES["L"], 23)
        self.assertEqual(iso6346.LETTER_VALUES["V"], 34)


if __name__ == "__main__":
    unittest.main()
