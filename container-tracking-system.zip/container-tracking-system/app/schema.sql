CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS ports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    unlocode TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    country TEXT NOT NULL,
    lat REAL NOT NULL,
    lon REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS containers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    container_no TEXT NOT NULL UNIQUE,
    size_type TEXT NOT NULL,
    owner TEXT,
    is_reefer INTEGER NOT NULL DEFAULT 0,
    temp_min REAL,
    temp_max REAL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS shipments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT NOT NULL UNIQUE,
    customer_id INTEGER NOT NULL REFERENCES users(id),
    container_id INTEGER NOT NULL REFERENCES containers(id),
    origin_port_id INTEGER NOT NULL REFERENCES ports(id),
    dest_port_id INTEGER NOT NULL REFERENCES ports(id),
    vessel TEXT,
    voyage TEXT,
    etd TEXT,
    eta TEXT,
    status TEXT NOT NULL DEFAULT 'BOOKED',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shipment_id INTEGER NOT NULL REFERENCES shipments(id) ON DELETE CASCADE,
    container_id INTEGER NOT NULL REFERENCES containers(id),
    event_type TEXT NOT NULL,
    status TEXT,
    lat REAL,
    lon REAL,
    temperature REAL,
    location_name TEXT,
    note TEXT,
    occurred_at TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT 'manual',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_events_shipment ON events(shipment_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_shipments_container ON shipments(container_id);
CREATE INDEX IF NOT EXISTS idx_shipments_customer ON shipments(customer_id);
