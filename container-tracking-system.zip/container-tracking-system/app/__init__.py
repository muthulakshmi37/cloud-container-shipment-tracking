"""Cloud-Based Container Shipment Tracking System - Flask application factory."""
import click
from flask import Flask, jsonify, request

from . import db
from .api import ApiError, bp as api_bp
from .config import default_config


def create_app(test_config=None):
    app = Flask(__name__, static_folder="static", static_url_path="")
    app.config.update(default_config())
    if test_config:
        app.config.update(test_config)

    db.init_app(app)
    app.register_blueprint(api_bp, url_prefix="/api")

    with app.app_context():
        db.init_db()
        if app.config["SEED_DEMO"]:
            from .seed import seed_if_empty
            seed_if_empty()

    @app.get("/")
    def index():
        return app.send_static_file("index.html")

    @app.after_request
    def add_headers(resp):
        origin = app.config["CORS_ORIGIN"]
        if origin and request.path.startswith("/api"):
            resp.headers["Access-Control-Allow-Origin"] = origin
            resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-API-Key"
            resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        return resp

    @app.errorhandler(ApiError)
    def api_error(err):
        return jsonify({"error": err.message}), err.status

    @app.errorhandler(404)
    def not_found(_e):
        if request.path.startswith("/api"):
            return jsonify({"error": "Endpoint not found."}), 404
        return app.send_static_file("index.html")

    @app.errorhandler(405)
    def bad_method(_e):
        return jsonify({"error": "Method not allowed."}), 405

    @app.errorhandler(500)
    def server_error(_e):
        return jsonify({"error": "Something went wrong on the server."}), 500

    @app.cli.command("seed")
    def seed_command():
        """Load demo ports, users, containers and shipments."""
        from .seed import seed_if_empty
        click.echo("Seeded demo data." if seed_if_empty() else "Database already has data; skipped.")

    return app
