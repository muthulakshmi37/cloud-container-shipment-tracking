"""REST API blueprint."""
import hmac
import re
import secrets
from functools import wraps

from flask import Blueprint, current_app, g, jsonify, request
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from werkzeug.security import check_password_hash, generate_password_hash

from . import iso6346
from .db import get_db
from .services import (AT_SEA, FINISHED, STATUSES, build_tracking, parse_ts,
                       to_iso, utcnow)

bp = Blueprint("api", __name__)

SIZE_TYPES = {"20GP", "40GP", "40HC", "20RF", "40RF"}
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class ApiError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.message, self.status = message, status


@bp.errorhandler(ApiError)
def _handle_api_error(err):
    return jsonify({"error": err.message}), err.status


# ---- auth helpers -------------------------------------------------------
def _serializer():
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt="auth-token")


def _user_public(u):
    return {"id": u["id"], "name": u["name"], "email": u["email"], "role": u["role"]}


def _current_user():
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    try:
        data = _serializer().loads(header[7:], max_age=current_app.config["TOKEN_MAX_AGE"])
    except (BadSignature, SignatureExpired):
        return None
    return get_db().execute("SELECT * FROM users WHERE id = ?", (data["uid"],)).fetchone()


def login_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        user = _current_user()
        if user is None:
            raise ApiError("Sign in to continue.", 401)
        g.user = user
        return fn(*a, **kw)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*a, **kw):
        if g.user["role"] != "admin":
            raise ApiError("This action needs an administrator account.", 403)
        return fn(*a, **kw)
    return wrapper


# ---- input helpers ------------------------------------------------------
def _json():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise ApiError("Send a JSON object in the request body.")
    return data


def _require(data, *fields):
    missing = [f for f in fields if data.get(f) in (None, "")]
    if missing:
        raise ApiError("Missing required field(s): " + ", ".join(missing))


def _float(data, key, lo=None, hi=None):
    if data.get(key) in (None, ""):
        return None
    try:
        v = float(data[key])
    except (TypeError, ValueError):
        raise ApiError(f"{key} must be a number.")
    if (lo is not None and v < lo) or (hi is not None and v > hi):
        raise ApiError(f"{key} must be between {lo} and {hi}.")
    return v


def _timestamp(data, key, default=None):
    if data.get(key) in (None, ""):
        return default
    try:
        return to_iso(parse_ts(data[key]))
    except ValueError:
        raise ApiError(f"{key} must be an ISO-8601 date-time, e.g. 2026-10-01T08:30:00Z.")


def _port_by_code(code):
    row = get_db().execute("SELECT * FROM ports WHERE unlocode = ?", ((code or "").upper(),)).fetchone()
    if row is None:
        raise ApiError(f"Unknown port code '{code}'. Use GET /api/ports for valid codes.", 404)
    return row


# ---- data loading -------------------------------------------------------
def _tracking_for(shipment):
    db = get_db()
    container = db.execute("SELECT * FROM containers WHERE id = ?", (shipment["container_id"],)).fetchone()
    origin = db.execute("SELECT * FROM ports WHERE id = ?", (shipment["origin_port_id"],)).fetchone()
    dest = db.execute("SELECT * FROM ports WHERE id = ?", (shipment["dest_port_id"],)).fetchone()
    events = db.execute("SELECT * FROM events WHERE shipment_id = ?", (shipment["id"],)).fetchall()
    return build_tracking(shipment, container, origin, dest, events, current_app.config["AVG_SPEED_KMH"])


def _visible_shipments():
    db = get_db()
    if g.user["role"] == "admin":
        return db.execute("SELECT * FROM shipments ORDER BY id DESC").fetchall()
    return db.execute("SELECT * FROM shipments WHERE customer_id = ? ORDER BY id DESC",
                      (g.user["id"],)).fetchall()


def _summary(t):
    """Trim a tracking document to what list views need."""
    keys = ("reference", "container_no", "size_type", "is_reefer", "status", "vessel", "origin",
            "destination", "planned_eta", "predicted_eta", "delay_hours", "progress_percent", "alerts")
    out = {k: t[k] for k in keys}
    out["last_position"] = t["last_position"]
    return out


def _active_shipment_for_container(container_id):
    db = get_db()
    row = db.execute(
        "SELECT * FROM shipments WHERE container_id = ? AND status != 'DELIVERED' ORDER BY id DESC LIMIT 1",
        (container_id,)).fetchone()
    if row is None:
        row = db.execute("SELECT * FROM shipments WHERE container_id = ? ORDER BY id DESC LIMIT 1",
                         (container_id,)).fetchone()
    return row


# ---- health / reference data -------------------------------------------
@bp.get("/health")
def health():
    get_db().execute("SELECT 1")
    return jsonify({"status": "ok"})


@bp.get("/ports")
def list_ports():
    rows = get_db().execute("SELECT * FROM ports ORDER BY name").fetchall()
    return jsonify([dict(r) for r in rows])


# ---- auth ---------------------------------------------------------------
@bp.post("/auth/register")
def register():
    data = _json()
    _require(data, "name", "email", "password")
    email = data["email"].strip().lower()
    if not EMAIL_RE.match(email):
        raise ApiError("Enter a valid email address.")
    if len(data["password"]) < 8:
        raise ApiError("Password must be at least 8 characters.")
    db = get_db()
    if db.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
        raise ApiError("An account with this email already exists.", 409)
    cur = db.execute(
        "INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, 'customer', ?)",
        (data["name"].strip(), email, generate_password_hash(data["password"]), to_iso(utcnow())))
    db.commit()
    user = db.execute("SELECT * FROM users WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify({"token": _serializer().dumps({"uid": user["id"]}), "user": _user_public(user)}), 201


@bp.post("/auth/login")
def login():
    data = _json()
    _require(data, "email", "password")
    user = get_db().execute("SELECT * FROM users WHERE email = ?", (data["email"].strip().lower(),)).fetchone()
    if user is None or not check_password_hash(user["password_hash"], data["password"]):
        raise ApiError("Email or password is incorrect.", 401)
    return jsonify({"token": _serializer().dumps({"uid": user["id"]}), "user": _user_public(user)})


@bp.get("/auth/me")
@login_required
def me():
    return jsonify(_user_public(g.user))


# ---- containers ---------------------------------------------------------
@bp.get("/containers")
@login_required
def list_containers():
    db = get_db()
    if g.user["role"] == "admin":
        rows = db.execute("SELECT * FROM containers ORDER BY container_no").fetchall()
    else:
        rows = db.execute(
            "SELECT DISTINCT c.* FROM containers c JOIN shipments s ON s.container_id = c.id "
            "WHERE s.customer_id = ? ORDER BY c.container_no", (g.user["id"],)).fetchall()
    return jsonify([dict(r) for r in rows])


@bp.post("/containers")
@admin_required
def create_container():
    data = _json()
    _require(data, "container_no", "size_type")
    number = iso6346.normalize(data["container_no"])
    if not iso6346.is_valid(number):
        raise ApiError("Container number is not valid under ISO 6346 (check the letters, digits and check digit).")
    size = str(data["size_type"]).upper()
    if size not in SIZE_TYPES:
        raise ApiError("size_type must be one of: " + ", ".join(sorted(SIZE_TYPES)))
    is_reefer = size.endswith("RF")
    tmin = _float(data, "temp_min", -60, 40) if is_reefer else None
    tmax = _float(data, "temp_max", -60, 40) if is_reefer else None
    if is_reefer:
        tmin = 2.0 if tmin is None else tmin
        tmax = 8.0 if tmax is None else tmax
        if tmin > tmax:
            raise ApiError("temp_min cannot be higher than temp_max.")
    db = get_db()
    if db.execute("SELECT 1 FROM containers WHERE container_no = ?", (number,)).fetchone():
        raise ApiError("This container is already registered.", 409)
    cur = db.execute(
        "INSERT INTO containers (container_no, size_type, owner, is_reefer, temp_min, temp_max, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (number, size, data.get("owner") or number[:3], int(is_reefer), tmin, tmax, to_iso(utcnow())))
    db.commit()
    row = db.execute("SELECT * FROM containers WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201


# ---- shipments ----------------------------------------------------------
@bp.get("/shipments")
@login_required
def list_shipments():
    status = (request.args.get("status") or "").upper()
    items = [_summary(_tracking_for(s)) for s in _visible_shipments()]
    if status:
        items = [i for i in items if i["status"] == status]
    return jsonify(items)


@bp.post("/shipments")
@admin_required
def create_shipment():
    data = _json()
    _require(data, "container_no", "origin", "destination")
    db = get_db()
    container = db.execute("SELECT * FROM containers WHERE container_no = ?",
                           (iso6346.normalize(data["container_no"]),)).fetchone()
    if container is None:
        raise ApiError("Container not found. Register it first.", 404)
    origin, dest = _port_by_code(data["origin"]), _port_by_code(data["destination"])
    if origin["id"] == dest["id"]:
        raise ApiError("Origin and destination must be different ports.")
    busy = db.execute("SELECT 1 FROM shipments WHERE container_id = ? AND status != 'DELIVERED'",
                      (container["id"],)).fetchone()
    if busy:
        raise ApiError("This container is already on an active shipment.", 409)

    customer_id = g.user["id"]
    if data.get("customer_email"):
        cust = db.execute("SELECT id FROM users WHERE email = ?", (data["customer_email"].strip().lower(),)).fetchone()
        if cust is None:
            raise ApiError("No user found with that customer_email.", 404)
        customer_id = cust["id"]

    etd, eta = _timestamp(data, "etd"), _timestamp(data, "eta")
    if etd and eta and eta <= etd:
        raise ApiError("eta must be later than etd.")
    reference = f"SHP-{utcnow():%Y}-{secrets.token_hex(3).upper()}"
    now = to_iso(utcnow())
    cur = db.execute(
        "INSERT INTO shipments (reference, customer_id, container_id, origin_port_id, dest_port_id, vessel, voyage, "
        "etd, eta, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'BOOKED', ?)",
        (reference, customer_id, container["id"], origin["id"], dest["id"], data.get("vessel"),
         data.get("voyage"), etd, eta, now))
    db.execute(
        "INSERT INTO events (shipment_id, container_id, event_type, status, lat, lon, location_name, note, "
        "occurred_at, source, created_at) VALUES (?, ?, 'BOOKED', 'BOOKED', ?, ?, ?, 'Booking created', ?, 'system', ?)",
        (cur.lastrowid, container["id"], origin["lat"], origin["lon"], origin["name"], now, now))
    db.commit()
    shipment = db.execute("SELECT * FROM shipments WHERE id = ?", (cur.lastrowid,)).fetchone()
    return jsonify(_tracking_for(shipment)), 201


@bp.get("/shipments/<reference>")
@login_required
def get_shipment(reference):
    shipment = get_db().execute("SELECT * FROM shipments WHERE reference = ?", (reference.upper(),)).fetchone()
    if shipment is None or (g.user["role"] != "admin" and shipment["customer_id"] != g.user["id"]):
        raise ApiError("Shipment not found.", 404)
    return jsonify(_tracking_for(shipment))


# ---- events (device / operator ingestion) -------------------------------
@bp.post("/events")
def add_event():
    device_ok = hmac.compare_digest(request.headers.get("X-API-Key", ""), current_app.config["DEVICE_API_KEY"]) \
        if request.headers.get("X-API-Key") else False
    source = "device"
    if not device_ok:
        user = _current_user()
        if user is None:
            raise ApiError("Provide a valid X-API-Key header or an administrator token.", 401)
        if user["role"] != "admin":
            raise ApiError("This action needs an administrator account.", 403)
        source = "operator"

    data = _json()
    _require(data, "container_no")
    db = get_db()
    container = db.execute("SELECT * FROM containers WHERE container_no = ?",
                           (iso6346.normalize(data["container_no"]),)).fetchone()
    if container is None:
        raise ApiError("Container not found.", 404)
    shipment = _active_shipment_for_container(container["id"])
    if shipment is None:
        raise ApiError("This container has no shipment to attach the event to.", 404)

    status = (data.get("status") or "").upper() or None
    if status and status not in STATUSES:
        raise ApiError("status must be one of: " + ", ".join(STATUSES))
    lat, lon = _float(data, "lat", -90, 90), _float(data, "lon", -180, 180)
    if (lat is None) != (lon is None):
        raise ApiError("Send lat and lon together.")
    temperature = _float(data, "temperature", -100, 100)
    occurred = _timestamp(data, "occurred_at", to_iso(utcnow()))
    event_type = (data.get("event_type") or status or "POSITION").upper()

    db.execute(
        "INSERT INTO events (shipment_id, container_id, event_type, status, lat, lon, temperature, location_name, "
        "note, occurred_at, source, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (shipment["id"], container["id"], event_type, status, lat, lon, temperature,
         data.get("location_name"), data.get("note"), occurred, source, to_iso(utcnow())))
    if status:
        db.execute("UPDATE shipments SET status = ? WHERE id = ?", (status, shipment["id"]))
    db.commit()
    shipment = db.execute("SELECT * FROM shipments WHERE id = ?", (shipment["id"],)).fetchone()
    t = _tracking_for(shipment)
    return jsonify({"reference": t["reference"], "status": t["status"], "alerts": t["alerts"],
                    "progress_percent": t["progress_percent"]}), 201


# ---- public tracking ----------------------------------------------------
@bp.get("/track/<identifier>")
def track(identifier):
    """Public lookup by container number or shipment reference (no customer data returned)."""
    db = get_db()
    shipment = db.execute("SELECT * FROM shipments WHERE reference = ?", (identifier.strip().upper(),)).fetchone()
    if shipment is None:
        container = db.execute("SELECT id FROM containers WHERE container_no = ?",
                               (iso6346.normalize(identifier),)).fetchone()
        if container:
            shipment = _active_shipment_for_container(container["id"])
    if shipment is None:
        raise ApiError("No shipment found for that container number or reference.", 404)
    return jsonify(_tracking_for(shipment))


# ---- dashboard ----------------------------------------------------------
@bp.get("/alerts")
@login_required
def alerts():
    out = []
    for s in _visible_shipments():
        t = _tracking_for(s)
        for a in t["alerts"]:
            out.append({**a, "reference": t["reference"], "container_no": t["container_no"]})
    out.sort(key=lambda a: 0 if a["severity"] == "critical" else 1)
    return jsonify(out)


@bp.get("/stats")
@login_required
def stats():
    by_status = {s: 0 for s in STATUSES}
    delayed = alert_count = 0
    trackings = [_tracking_for(s) for s in _visible_shipments()]
    for t in trackings:
        by_status[t["status"]] += 1
        alert_count += len(t["alerts"])
        delayed += any(a["type"] == "DELAY" for a in t["alerts"])
    return jsonify({
        "total_shipments": len(trackings),
        "at_sea": sum(1 for t in trackings if t["status"] in AT_SEA),
        "completed": sum(1 for t in trackings if t["status"] in FINISHED),
        "delayed": delayed,
        "open_alerts": alert_count,
        "by_status": by_status,
    })
