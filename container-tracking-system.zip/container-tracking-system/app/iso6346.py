"""ISO 6346 shipping-container number validation.

A container number is: 3-letter owner code + category letter (U, J or Z)
+ 6-digit serial + 1 check digit, e.g. CSQU3054383.
"""
import re
import string

_PATTERN = re.compile(r"^[A-Z]{3}[UJZ][0-9]{7}$")

# Letter values start at 10 and skip multiples of 11 (11, 22, 33).
LETTER_VALUES = {}
_n = 10
for _ch in string.ascii_uppercase:
    if _n % 11 == 0:
        _n += 1
    LETTER_VALUES[_ch] = _n
    _n += 1


def normalize(number):
    return re.sub(r"[\s\-]", "", (number or "")).upper()


def check_digit(first_ten):
    """Compute the check digit for the first 10 characters."""
    total = 0
    for position, char in enumerate(first_ten):
        value = LETTER_VALUES[char] if char.isalpha() else int(char)
        total += value * (2 ** position)
    return total % 11 % 10


def is_valid(number):
    number = normalize(number)
    if not _PATTERN.match(number):
        return False
    return check_digit(number[:10]) == int(number[10])
