"""Configuration loaded from environment variables (12-factor style)."""
import os


def default_config():
    return {
        "SECRET_KEY": os.environ.get("SECRET_KEY", "dev-secret-change-me"),
        "DATABASE_PATH": os.environ.get("DATABASE_PATH", os.path.join(os.getcwd(), "data", "tracking.db")),
        "DEVICE_API_KEY": os.environ.get("DEVICE_API_KEY", "dev-device-key"),
        "TOKEN_MAX_AGE": int(os.environ.get("TOKEN_MAX_AGE", "86400")),
        "AVG_SPEED_KMH": float(os.environ.get("AVG_SPEED_KMH", "24")),  # ~13 knots container ship
        "CORS_ORIGIN": os.environ.get("CORS_ORIGIN", ""),
        "SEED_DEMO": os.environ.get("SEED_DEMO", "false").lower() == "true",
    }
