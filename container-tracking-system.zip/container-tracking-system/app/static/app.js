/* BoxTrace front end – plain JavaScript, talks to the REST API under /api */
const API = (window.API_BASE || "") + "/api";
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

let token = localStorage.getItem("bt_token");
let user = JSON.parse(localStorage.getItem("bt_user") || "null");
let map, layer, ports = [];

async function api(path, opts = {}) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = "Bearer " + token;
  const res = await fetch(API + path, { ...opts, headers });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && token) signOut();
    throw new Error(body.error || "Request failed (" + res.status + ")");
  }
  return body;
}

const fmtDate = (s) => (s ? new Date(s).toLocaleString([], { dateStyle: "medium", timeStyle: "short" }) : "Not set");
const label = (s) => s.replaceAll("_", " ").toLowerCase().replace(/^./, (c) => c.toUpperCase());
const pillClass = (s) => (["IN_TRANSIT", "LOADED", "TRANSSHIPMENT"].includes(s) ? "sea" : ["ARRIVED", "DISCHARGED", "DELIVERED"].includes(s) ? "done" : "wait");

/* ---------- routing / session ---------- */
function show(view) {
  if (view === "dashboard" && !user) view = "track";
  if (view === "admin" && user?.role !== "admin") view = "track";
  $$(".view").forEach((v) => (v.hidden = v.id !== "view-" + view));
  $$("#nav a").forEach((a) => a.classList.toggle("active", a.dataset.view === view));
  if (view === "track") setTimeout(() => map && map.invalidateSize(), 50);
  if (view === "dashboard") loadDashboard();
}
const route = () => show((location.hash || "#track").slice(1));
window.addEventListener("hashchange", route);

function renderSession() {
  $("#whoami").textContent = user ? user.name : "";
  $("#btn-login").hidden = !!user;
  $("#btn-logout").hidden = !user;
  $$(".auth-only").forEach((e) => (e.hidden = !user));
  $$(".admin-only").forEach((e) => (e.hidden = user?.role !== "admin"));
}
function signOut() {
  token = null; user = null;
  localStorage.removeItem("bt_token"); localStorage.removeItem("bt_user");
  renderSession(); route();
}
$("#btn-logout").onclick = () => { signOut(); location.hash = "#track"; };

/* ---------- auth dialog ---------- */
let registering = false;
function setAuthMode(reg) {
  registering = reg;
  $("#auth-title").textContent = reg ? "Create an account" : "Sign in";
  $("#auth-submit").textContent = reg ? "Create account" : "Sign in";
  $("#auth-toggle").textContent = reg ? "I have an account" : "Create an account";
  $("#name-field").hidden = !reg;
  $("#name-field input").required = reg;
}
$("#btn-login").onclick = () => { setAuthMode(false); $("#auth-msg").textContent = ""; $("#auth-dialog").showModal(); };
$("#auth-toggle").onclick = () => setAuthMode(!registering);
$("#auth-cancel").onclick = () => $("#auth-dialog").close();
$("#auth-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  try {
    const out = await api(registering ? "/auth/register" : "/auth/login", { method: "POST", body: JSON.stringify(f) });
    token = out.token; user = out.user;
    localStorage.setItem("bt_token", token); localStorage.setItem("bt_user", JSON.stringify(user));
    $("#auth-dialog").close(); e.target.reset(); renderSession();
    location.hash = "#dashboard"; route();
  } catch (err) { $("#auth-msg").textContent = err.message; }
});

/* ---------- map ---------- */
function initMap() {
  map = L.map("map", { worldCopyJump: true }).setView([20, 60], 3);
  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 18, attribution: "&copy; OpenStreetMap contributors",
  }).addTo(map);
  layer = L.layerGroup().addTo(map);
}

function drawRoute(t) {
  layer.clearLayers();
  const o = [t.origin.lat, t.origin.lon], d = [t.destination.lat, t.destination.lon];
  L.polyline([o, d], { color: "#7c8b95", weight: 2, dashArray: "6 8" }).addTo(layer);
  const trail = t.events.filter((e) => e.lat != null).map((e) => [e.lat, e.lon]);
  if (trail.length > 1) L.polyline(trail, { color: "#0f6b75", weight: 4 }).addTo(layer);
  L.circleMarker(o, { radius: 6, color: "#22303c", fillColor: "#fff", fillOpacity: 1 }).bindTooltip(t.origin.name, { permanent: false }).addTo(layer);
  L.circleMarker(d, { radius: 6, color: "#22303c", fillColor: "#22303c", fillOpacity: 1 }).bindTooltip(t.destination.name).addTo(layer);
  if (t.last_position) {
    const p = [t.last_position.lat, t.last_position.lon];
    L.circleMarker(p, { radius: 10, color: "#22303c", weight: 3, fillColor: "#f2b705", fillOpacity: 1 })
      .bindPopup("<b>" + esc(t.container_no) + "</b><br>" + esc(fmtDate(t.last_position.at))).addTo(layer).openPopup();
  }
  map.fitBounds(L.latLngBounds([o, d, ...trail]).pad(0.25));
}

/* ---------- track view ---------- */
async function track(id) {
  const msg = $("#track-msg"); msg.textContent = "";
  try {
    const t = await api("/track/" + encodeURIComponent(id.trim()));
    $("#track-empty").hidden = true; $("#track-result").hidden = false;
    $("#r-number").textContent = t.container_no;
    const s = $("#r-status"); s.textContent = label(t.status); s.className = "pill " + pillClass(t.status);
    $("#r-sub").textContent = [t.reference, t.size_type, t.vessel && t.vessel + (t.voyage ? " · " + t.voyage : "")].filter(Boolean).join("  ·  ");
    $("#r-origin").textContent = t.origin.name; $("#r-dest").textContent = t.destination.name;
    $("#r-bar").style.width = t.progress_percent + "%";
    $("#r-planned").textContent = fmtDate(t.planned_eta);
    $("#r-predicted").textContent = fmtDate(t.predicted_eta) + (t.delay_hours >= 24 ? " (" + Math.round(t.delay_hours / 24) + " d late)" : "");
    $("#r-dist").textContent = t.distance_remaining_km == null ? "Not known yet" : t.distance_remaining_km.toLocaleString() + " km";
    $("#r-last").textContent = t.last_position ? fmtDate(t.last_position.at) : "No position yet";
    $("#r-alerts").innerHTML = t.alerts.map((a) => `<li class="${esc(a.severity)}">${esc(a.message)}</li>`).join("");
    $("#r-events").innerHTML = [...t.events].reverse().map((e) => `
      <li><strong>${esc(label(e.status || e.event_type))}</strong>${e.location_name ? " – " + esc(e.location_name) : ""}
      ${e.temperature != null ? " · " + esc(e.temperature) + " °C" : ""}${e.note ? "<br>" + esc(e.note) : ""}
      <time datetime="${esc(e.occurred_at)}">${esc(fmtDate(e.occurred_at))}</time></li>`).join("");
    drawRoute(t);
    $("#track-input").value = t.container_no;
  } catch (err) {
    $("#track-result").hidden = true; $("#track-empty").hidden = false; msg.textContent = err.message;
  }
}
$("#track-form").addEventListener("submit", (e) => { e.preventDefault(); track($("#track-input").value); });
$$(".demo").forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); track(a.textContent); }));

/* ---------- dashboard ---------- */
async function loadDashboard() {
  try {
    const [st, alerts, ships] = await Promise.all([api("/stats"), api("/alerts"), api("/shipments")]);
    $("#stats").innerHTML = [
      ["total_shipments", "Shipments"], ["at_sea", "At sea"], ["completed", "Arrived"], ["delayed", "Delayed"], ["open_alerts", "Open alerts"],
    ].map(([k, l]) => `<div><strong>${st[k]}</strong><span>${l}</span></div>`).join("");
    $("#alert-list").innerHTML = alerts.length
      ? alerts.map((a) => `<li class="${esc(a.severity)}"><span>${esc(a.message)}</span><span class="mono">${esc(a.container_no)}</span></li>`).join("")
      : "<li>No open alerts. Everything is on schedule.</li>";
    $("#ship-rows").innerHTML = ships.map((s) => `
      <tr data-c="${esc(s.container_no)}">
        <td class="mono">${esc(s.container_no)}</td><td>${esc(s.reference)}</td>
        <td>${esc(s.origin.name)} to ${esc(s.destination.name)}</td>
        <td><span class="pill ${pillClass(s.status)}">${esc(label(s.status))}</span></td>
        <td><span class="mini"><i style="width:${s.progress_percent}%"></i></span>${Math.round(s.progress_percent)}%</td>
        <td>${esc(fmtDate(s.predicted_eta))}</td></tr>`).join("") || `<tr><td colspan="6">No shipments yet.</td></tr>`;
    $$("#ship-rows tr[data-c]").forEach((r) => r.onclick = () => { location.hash = "#track"; track(r.dataset.c); });
  } catch (err) { $("#alert-list").innerHTML = `<li class="critical">${esc(err.message)}</li>`; }
}

/* ---------- admin forms ---------- */
async function loadPorts() {
  ports = await api("/ports");
  const opts = ports.map((p) => `<option value="${esc(p.unlocode)}">${esc(p.name)} (${esc(p.unlocode)})</option>`).join("");
  $$("select.ports").forEach((s) => (s.innerHTML = opts));
}
function bindForm(id, path, prep) {
  const form = $(id);
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const msg = $(".msg", form); msg.className = "msg"; msg.textContent = "";
    const body = {};
    new FormData(form).forEach((v, k) => { if (v !== "") body[k] = v; });
    if (prep) prep(body);
    try {
      const out = await api(path, { method: "POST", body: JSON.stringify(body) });
      msg.className = "msg ok"; msg.textContent = "Saved" + (out.reference ? " (" + out.reference + ")" : "") + ".";
      form.reset();
    } catch (err) { msg.textContent = err.message; }
  });
}
const localToIso = (b, k) => { if (b[k]) b[k] = new Date(b[k]).toISOString(); };
bindForm("#f-container", "/containers");
bindForm("#f-shipment", "/shipments", (b) => { localToIso(b, "etd"); localToIso(b, "eta"); });
bindForm("#f-event", "/events");

/* ---------- start ---------- */
initMap(); renderSession(); route();
loadPorts().catch(() => {});
