"""Demo data: ports, two users, and shipments in different states."""
from datetime import timedelta

from werkzeug.security import generate_password_hash

from . import iso6346
from .db import get_db
from .services import haversine_km, interpolate, to_iso, utcnow

PORTS = [
    ("INNSA", "Nhava Sheva (JNPT)", "India", 18.9489, 72.9510),
    ("INMAA", "Chennai", "India", 13.0827, 80.2707),
    ("AEJEA", "Jebel Ali", "UAE", 25.0116, 55.0610),
    ("SGSIN", "Singapore", "Singapore", 1.2644, 103.8200),
    ("CNSHA", "Shanghai", "China", 31.2304, 121.4737),
    ("KRPUS", "Busan", "South Korea", 35.1028, 129.0403),
    ("NLRTM", "Rotterdam", "Netherlands", 51.9490, 4.1420),
    ("DEHAM", "Hamburg", "Germany", 53.5461, 9.9661),
    ("GBFXT", "Felixstowe", "United Kingdom", 51.9540, 1.3510),
    ("USLAX", "Los Angeles", "USA", 33.7292, -118.2620),
    ("USLGB", "Long Beach", "USA", 33.7540, -118.2160),
    ("USNYC", "New York", "USA", 40.6680, -74.0450),
    ("LKCMB", "Colombo", "Sri Lanka", 6.9497, 79.8428),
    ("EGPSD", "Port Said", "Egypt", 31.2653, 32.3019),
]

# (origin, dest, serial, size, status, fraction travelled, days since departure,
#  planned ETA offset from now in days or None, vessel, voyage, reefer temps)
SCENARIOS = [
    ("INNSA", "NLRTM", "204518", "40HC", "IN_TRANSIT", 0.45, 9, None, "MV Blue Meridian", "BM-142W", None),
    ("CNSHA", "USLAX", "778120", "40RF", "IN_TRANSIT", 0.55, 8, None, "MV Pacific Anchor", "PA-077E", (4.2, 11.8)),
    ("SGSIN", "DEHAM", "352906", "20GP", "IN_TRANSIT", 0.40, 10, 3, "MV Northern Crest", "NC-310W", None),
    ("INMAA", "AEJEA", "610447", "40GP", "ARRIVED", 1.0, 6, -1, "MV Gulf Runner", "GR-021N", None),
    ("KRPUS", "USLGB", "993215", "40HC", "BOOKED", 0.0, -3, 24, "MV Harbor Star", "HS-514E", None),
    ("LKCMB", "GBFXT", "128873", "20GP", "TRANSSHIPMENT", 0.30, 7, None, "MV Coral Trader", "CT-208W", None),
]


def seed_if_empty():
    db = get_db()
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
        return False
    now = utcnow()
    stamp = to_iso(now)

    for code, name, country, lat, lon in PORTS:
        db.execute("INSERT OR IGNORE INTO ports (unlocode, name, country, lat, lon) VALUES (?, ?, ?, ?, ?)",
                   (code, name, country, lat, lon))
    db.execute("INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, 'admin', ?)",
               ("Operations Admin", "admin@boxtrace.test", generate_password_hash("admin12345"), stamp))
    cust = db.execute(
        "INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?, ?, ?, 'customer', ?)",
        ("Demo Customer", "customer@boxtrace.test", generate_password_hash("customer12345"), stamp)).lastrowid

    ports = {r["unlocode"]: r for r in db.execute("SELECT * FROM ports")}
    for i, (o, d, serial, size, status, frac, days, eta_off, vessel, voyage, temps) in enumerate(SCENARIOS, 1):
        first10 = "BXTU" + serial
        number = first10 + str(iso6346.check_digit(first10))
        reefer = size.endswith("RF")
        cid = db.execute(
            "INSERT INTO containers (container_no, size_type, owner, is_reefer, temp_min, temp_max, created_at) "
            "VALUES (?, ?, 'BoxTrace Lines', ?, ?, ?, ?)",
            (number, size, int(reefer), 2.0 if reefer else None, 8.0 if reefer else None, stamp)).lastrowid

        po, pd = ports[o], ports[d]
        total = haversine_km(po["lat"], po["lon"], pd["lat"], pd["lon"])
        etd = now - timedelta(days=days)
        remaining_h = total * (1 - frac) / 24
        eta = now + timedelta(days=eta_off) if eta_off is not None else now + timedelta(hours=remaining_h + 18)
        if status == "BOOKED":
            etd = now + timedelta(days=3)
        sid = db.execute(
            "INSERT INTO shipments (reference, customer_id, container_id, origin_port_id, dest_port_id, vessel, "
            "voyage, etd, eta, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (f"SHP-{now:%Y}-{100000 + i}", cust, cid, po["id"], pd["id"], vessel, voyage,
             to_iso(etd), to_iso(eta), status, stamp)).lastrowid

        def add(kind, at, lat=None, lon=None, place=None, temp=None, note=None, st=None):
            db.execute(
                "INSERT INTO events (shipment_id, container_id, event_type, status, lat, lon, temperature, "
                "location_name, note, occurred_at, source, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'seed', ?)",
                (sid, cid, kind, st, lat, lon, temp, place, note, to_iso(at), stamp))

        add("BOOKED", now - timedelta(days=max(days, 0) + 5), po["lat"], po["lon"], po["name"], st="BOOKED",
            note="Booking created")
        if status == "BOOKED":
            continue
        add("GATED_IN", etd - timedelta(days=1), po["lat"], po["lon"], po["name"], st="GATED_IN",
            note="Container received at terminal")
        add("LOADED", etd - timedelta(hours=3), po["lat"], po["lon"], po["name"], st="LOADED",
            note=f"Loaded on {vessel}")
        steps = 6 if frac < 1 else 8
        last_at = now - timedelta(hours=2)
        for k in range(1, steps + 1):
            f = frac * k / steps
            lat, lon = interpolate(po["lat"], po["lon"], pd["lat"], pd["lon"], f)
            at = etd + (last_at - etd) * k / steps
            temp = None
            if temps:
                temp = 4.0 + (k % 3) * 0.3 if k < steps else temps[1]
            kind = "POSITION"
            add(kind, at, round(lat, 4), round(lon, 4), None, temp,
                st="TRANSSHIPMENT" if status == "TRANSSHIPMENT" and k == steps else "IN_TRANSIT")
        if status == "ARRIVED":
            add("ARRIVED", now - timedelta(hours=5), pd["lat"], pd["lon"], pd["name"], st="ARRIVED",
                note="Vessel berthed")
    db.commit()
    return True
