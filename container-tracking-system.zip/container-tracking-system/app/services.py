"""Tracking logic: distance, progress, ETA prediction and alert rules."""
import math
from datetime import datetime, timedelta, timezone

EARTH_KM = 6371.0088

STATUSES = [
    "BOOKED", "GATED_IN", "LOADED", "IN_TRANSIT", "TRANSSHIPMENT",
    "ARRIVED", "DISCHARGED", "DELIVERED",
]
AT_SEA = {"LOADED", "IN_TRANSIT", "TRANSSHIPMENT"}
FINISHED = {"ARRIVED", "DISCHARGED", "DELIVERED"}


# ---- time helpers -------------------------------------------------------
def utcnow():
    return datetime.now(timezone.utc)


def to_iso(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_ts(value):
    """Parse an ISO-8601 string into an aware UTC datetime (None if empty)."""
    if not value:
        return None
    dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


# ---- geo helpers --------------------------------------------------------
def haversine_km(lat1, lon1, lat2, lon2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = p2 - p1
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * EARTH_KM * math.asin(math.sqrt(a))


def interpolate(lat1, lon1, lat2, lon2, fraction):
    """Point on the great circle between two coordinates (fraction 0..1)."""
    phi1, lmb1, phi2, lmb2 = map(math.radians, (lat1, lon1, lat2, lon2))
    d = haversine_km(lat1, lon1, lat2, lon2) / EARTH_KM
    if d == 0:
        return lat1, lon1
    a = math.sin((1 - fraction) * d) / math.sin(d)
    b = math.sin(fraction * d) / math.sin(d)
    x = a * math.cos(phi1) * math.cos(lmb1) + b * math.cos(phi2) * math.cos(lmb2)
    y = a * math.cos(phi1) * math.sin(lmb1) + b * math.cos(phi2) * math.sin(lmb2)
    z = a * math.sin(phi1) + b * math.sin(phi2)
    return math.degrees(math.atan2(z, math.hypot(x, y))), math.degrees(math.atan2(y, x))


# ---- tracking summary ---------------------------------------------------
def build_tracking(shipment, container, origin, dest, events, speed_kmh, now=None):
    """Combine DB rows into one tracking document (progress, ETA, alerts)."""
    now = now or utcnow()
    events = sorted(events, key=lambda e: (e["occurred_at"], e["id"]))
    positioned = [e for e in events if e["lat"] is not None and e["lon"] is not None]
    last_pos = positioned[-1] if positioned else None
    last_event = events[-1] if events else None
    status = shipment["status"]

    total_km = haversine_km(origin["lat"], origin["lon"], dest["lat"], dest["lon"])
    remaining_km = None
    progress = 0.0
    if status in FINISHED:
        remaining_km, progress = 0.0, 100.0
    elif last_pos is not None:
        remaining_km = haversine_km(last_pos["lat"], last_pos["lon"], dest["lat"], dest["lon"])
        if total_km > 0:
            progress = max(0.0, min(99.0, (1 - remaining_km / total_km) * 100))

    planned_eta = parse_ts(shipment["eta"])
    predicted_eta = planned_eta
    if status in AT_SEA and last_pos is not None and speed_kmh > 0:
        predicted_eta = parse_ts(last_pos["occurred_at"]) + timedelta(hours=remaining_km / speed_kmh)

    delay_hours = 0.0
    if status not in FINISHED and planned_eta and predicted_eta:
        delay_hours = max(0.0, (predicted_eta - planned_eta).total_seconds() / 3600)
        if status in {"BOOKED", "GATED_IN"} and now > planned_eta:
            delay_hours = max(delay_hours, (now - planned_eta).total_seconds() / 3600)

    alerts = compute_alerts(status, container, events, last_event, delay_hours, now)

    return {
        "reference": shipment["reference"],
        "container_no": container["container_no"],
        "size_type": container["size_type"],
        "is_reefer": bool(container["is_reefer"]),
        "status": status,
        "vessel": shipment["vessel"],
        "voyage": shipment["voyage"],
        "origin": _port(origin),
        "destination": _port(dest),
        "etd": shipment["etd"],
        "planned_eta": shipment["eta"],
        "predicted_eta": to_iso(predicted_eta) if predicted_eta else None,
        "delay_hours": round(delay_hours, 1),
        "distance_total_km": round(total_km),
        "distance_remaining_km": None if remaining_km is None else round(remaining_km),
        "progress_percent": round(progress, 1),
        "last_position": None if not last_pos else {
            "lat": last_pos["lat"], "lon": last_pos["lon"],
            "at": last_pos["occurred_at"], "location_name": last_pos["location_name"],
        },
        "alerts": alerts,
        "events": [_event(e) for e in events],
    }


def compute_alerts(status, container, events, last_event, delay_hours, now):
    alerts = []
    if status not in FINISHED and delay_hours >= 24:
        sev = "critical" if delay_hours >= 72 else "warning"
        alerts.append({
            "type": "DELAY", "severity": sev,
            "message": f"Running about {round(delay_hours / 24, 1)} days behind the planned arrival.",
        })
    if container["is_reefer"]:
        temps = [e for e in events if e["temperature"] is not None]
        if temps:
            t = temps[-1]["temperature"]
            lo, hi = container["temp_min"], container["temp_max"]
            if (lo is not None and t < lo) or (hi is not None and t > hi):
                alerts.append({
                    "type": "TEMPERATURE", "severity": "critical",
                    "message": f"Cargo temperature {t:.1f} °C is outside the {lo:g} to {hi:g} °C range.",
                })
    if status in AT_SEA and last_event is not None:
        age_h = (now - parse_ts(last_event["occurred_at"])).total_seconds() / 3600
        if age_h > 12:
            alerts.append({
                "type": "STALE", "severity": "warning",
                "message": f"No update received for {round(age_h)} hours.",
            })
    return alerts


def _port(p):
    return {"unlocode": p["unlocode"], "name": p["name"], "country": p["country"],
            "lat": p["lat"], "lon": p["lon"]}


def _event(e):
    return {
        "id": e["id"], "event_type": e["event_type"], "status": e["status"],
        "lat": e["lat"], "lon": e["lon"], "temperature": e["temperature"],
        "location_name": e["location_name"], "note": e["note"],
        "occurred_at": e["occurred_at"], "source": e["source"],
    }
